/*name = "홍길동";
age = 30;
console.log(name,age);

"use strict"
name = "홍길동";
age = 30;
console.log(name,age);

"use strict"
var name;
name = "홍길동";
var age = 30;
console.log(name,age);

"use strict"
var name;
name = "홍길동";
name="임꺽정";
name
="유관순";
name=
"오호라";
console.log(name);


var name;
console.log(typeof name);

var name = "홍길동";
console.log(typeof name);

var name = 10;
console.log(typeof name);

var name = 3.14;
console.log(typeof name);

var name = undefined
console.log(typeof name);

var name = []
console.log(typeof name);

var name = new Object();
console.log(typeof name);

var name = NaN;
console.log(typeof name);

var name = null;
console.log(typeof name);

*/

/*static type binding
 - 정적 바인딩
 변수의 용도를 고정하는 방식
 프로그램의 크기가 큰것
 C,C++,C#,JAVA
  dinamic type binding
- 동적 바인딩
 변수의 용도를 가변하는 방식
 프로그램의 크기가 작은것
 script

 class test1{
public static void main(String[] args){
   int a;


 }
}
*/

class test1 {
  public static void main(String[]args){
    int a;
    a = 100;
    
  }
}
