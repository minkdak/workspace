class test1{
  public static void main(String[]args){
    int a = 100;
    
  }
}
