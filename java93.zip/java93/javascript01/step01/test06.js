/* 주제: 변수에 값 할당(=배정; assignment)
- 메모리(변수)에 값을 저장하는 방법
- assignment operator(할당연산자=배정연산자)  "=" 연산자를 사용한다.
- 문법
변수명 = 값;
*/
"use strict"
var name;
name = "홍길동";//가장 좋은 방법
name= "임꺽정";
name
="유관순";
name=
"오호라"; // 길때 사용하기도 함
console.log(name);
