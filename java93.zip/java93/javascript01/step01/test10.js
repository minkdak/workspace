"use strict"
var name = "홍길동";
{
 var name = "임꺽정";
 console.log(name);
}
console.log(name);

{
  var age = 20;
}
console.log(age);
