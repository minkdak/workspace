"use strict"
var name = "홍길동";
name = "임꺽정";
console.log(name);

let name2 = "홍길동";
name2 = "임꺽정";
console.log(name);

const name3 = "홍길동";
name3 = "임꺽정";
console.log(name3);
