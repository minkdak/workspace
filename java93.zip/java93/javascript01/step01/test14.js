"use strict"
const name = "홍길동";
console.log(name);

const age;
age = 20;
console.log(age);
