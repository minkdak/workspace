"use strict"
var name = "홍길동";
{
  let name = "임꺽정";
  console.log(name);
}
console.log(name);

{
  let age = 20;
  console.log(age);
}
console.log(age);
