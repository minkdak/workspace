"use strict"
var name = "홍길동";
var name = "임꺽정";
console.log(name);
