/* 주제: 변수 선언과 strict 모드 II
- strict 모드에서 변수를 선언하기
- 문법
var 변수명;
변수명 = 값;

var 변수명 = 값;
*/
"use strict"
var name;
name = "홍길동";
var age;
age = 30;
console.log(name, age);
