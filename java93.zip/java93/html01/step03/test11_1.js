var btn = document.getElementById("closeBtn");
btn.addEventListener('click', function() {
  var adDiv = document.getElementById("ad");
  adDiv.style.display = "none";
});
